//
//  File.swift
//  StudINA
//
//  Created by Vivien Christy Apriyanti on 20/04/22.
//


import Foundation

struct QuizModel  {
    var img : String
    var text : String
    var answer : [String]
    var correct : Int
}

var myQuiz : [QuizModel] = [
        QuizModel(
        img : "12",
        text: "This is traditional house from DKI Jakarta. What is it called?",
        answer: ["Rumah Kebaya","Baduy","Rakit Limas","Nuwo Sesat"],
        correct: 0),
         
        QuizModel(
        img : "1",
        text: "This is Krong Bade. Where is it come from?",
        answer: ["North Sumatera","West Sumatera","Nanggroe Aceh Darussalam","Riau"],
        correct: 2),
         
        QuizModel(
        img : "3",
        text: "This is traditional house from West Sumatera. What is it called?",
        answer: ["Selaso Jatuh Kembar","Rumah Gadang","Potong Limas","Bubungan Limas"],
        correct: 1),
         
        QuizModel(
        img : "5",
        text: "This is Potong Limas. Where is it come from?",
        answer: ["Riau","Riau Islands","Bangka Belitung","Lampung"],
        correct: 1),
         
        QuizModel(
        img : "20",
        text: "This is Betang from Central Kalimantan. How many people each house is inhabitated?",
        answer: ["20-50","50-80","90-120","100-150"],
        correct: 3),
        
        QuizModel(
        img : "22",
        text: "This is Dulohupa. Where is it come from?",
        answer: ["Gorontalo","West Sulawesi","Central Sulawesi","South Sulawesi"],
        correct: 0),
        
        QuizModel(
        img : "28",
        text: "This is traditional house from Bali. What is it called?",
        answer: ["Buton","Tongkonan","Gapura Candi Bentar","Musalaki"],
        correct: 2),
        
        QuizModel(
        img : "24",
        text: "This is traditional house from Central Sulawesi. What is it called?",
        answer: ["Souraja","Rumah Boyang","Dulohupa","Baloy"],
        correct: 0),
        
        QuizModel(
        img : "21",
        text: "This is Rumah Baloy. Where is it come from?",
        answer: ["South Kalimantan","North Kalimantan","Central Kalimantan","East Kalimantan"],
        correct: 1),
        
        QuizModel(
        img : "34",
        text: "This is Honai. Where is it come from?",
        answer: ["Maluku","North Maluku","West Papua","Papua"],
        correct: 3),
    ]
     
func SaveScore(quiz : String , score : Int){
        UserDefaults.standard.set(score, forKey: quiz)
}
     
func LoadScore (quiz : String) -> Int{
        return UserDefaults.standard.integer(forKey: quiz)
}


