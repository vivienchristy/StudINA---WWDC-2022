#StudINA (Study Indonesia) 
Hi👋! I am Vivien Christy Apriyanti from Batam, Indonesia. I am a Information Systems student who started learning iOS App Development at Apple Developer Academy @Infinite Learning Batam.

##About This App
Indonesia is a country with various ethnicities and cultures. Ethnic groups in Indonesia are often associated with their own distinctive form of Rumah Adat. Rumah Adat (rumah is house, and adat is tradition. Rumah adat is traditional house) is one of Indonesia's cultural heritage.

Unfortunately, Indonesia’s Rumah Adat are threatened with extinction due to economic, technological, and social changes. Many Indonesians are no longer familiar with Rumah Adat, including me.

As Indonesian, we should protect this cultural heritage. Therefore, I created this app to help Indonesians or other people who want to learn Rumah Adat of each province in Indonesia. We will learn it by flashcards and quiz. The flashcard will provide information about the Rumah Adat. After learning by flashcard, the user will be asked to take a quiz to review their knowledge. 

Let's learn together 😆

##Credits
###Sounds
1. Correct sound on Quiz page : from [Pixabay.com](https://pixabay.com/sound-effects/correct-6033/)
2. Wrong sound on Quiz page : from [Pixabay.com](https://pixabay.com/sound-effects/failure-drum-sound-effect-2-7184/)

###Images
1. App logo (traditional house illustration) : from [Freepik.com](https://www.freepik.com/vectors/traditional-house)
2. Bakso (meatball in Indonesia) : from [Freepik.com](https://www.freepik.com/vectors/indonesian-food)
3. Es Cendol (one of the Indonesian drinks) : from Canva.com by Sparklestroke Global
4. Rumah Adat images : from Wikipedia.com or other websites, you could see the details [here](https://docs.google.com/document/d/1s6YBUSYMuLqRNWqQL8noVUDS5iV9T-cJ8mt7FiXjpEc/edit?usp=sharing)
