//
//  File.swift
//  StudINA
//
//  Created by Vivien Christy Apriyanti on 20/04/22.
//

import SwiftUI

struct ProgressBar: View {
    var progress: CGFloat
    
    var body: some View {
        ZStack(alignment: .leading) {
            Rectangle()
                .frame(minWidth:350, maxHeight: 6)
                .foregroundColor(Color(red: 0.66, green: 0.44, blue: 0.33, opacity: 0.50))
                .cornerRadius(10)
                .padding(.horizontal)
            Rectangle()
                .frame(width: progress, height: 4)
                .foregroundColor(Color("AccentColor"))
                .cornerRadius(10)
                .padding(.horizontal)
            
        }
    }
}

struct ProgressBar_Previews: PreviewProvider {
    static var previews: some View {
        ProgressBar(progress: 10)
    }
}
