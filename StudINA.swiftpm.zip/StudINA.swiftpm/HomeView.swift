//
//  File.swift
//  StudINA
//
//  Created by Vivien Christy Apriyanti on 24/04/22.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
            ZStack {
                Color(red: 0.97, green: 0.91, blue: 0.84, opacity: 1.00).edgesIgnoringSafeArea(.all)
                VStack {
                    Text("Learn more about Indonesia's")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                    Image("welcomeLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: 350, maxHeight: 350, alignment: .center)
                    NavigationLink(destination: FlashcardView()) {
                        Text("Learn with Flashcard")
                                .font(.system(size: 20))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .frame(width:280, height: 50)
                                .background(Color("AccentColor"))
                                .cornerRadius(8)
                                .padding(.bottom,5)
                        }
                    NavigationLink(destination: QuizView()) {
                        Text("Take a Quiz")
                                .font(.system(size: 20))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .frame(width:280, height: 50)
                                .background(Color("AccentColor"))
                                .cornerRadius(8)
                                .padding(.bottom,5)
                        }
                }
            }
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
    }
}

struct HomeView_Previews: PreviewProvider {
   static var previews: some View {
       HomeView().previewDevice(PreviewDevice(rawValue: "iPhone 13")).previewInterfaceOrientation(.portrait)
   }
}

