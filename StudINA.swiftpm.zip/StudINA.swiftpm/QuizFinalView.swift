//
//  File.swift
//  StudINA
//
//  Created by Vivien Christy Apriyanti on 20/04/22.
//

import SwiftUI

struct QuizFinalView : View {
    var score : Int
    var body: some View {
        ZStack{
            Color(red: 0.97, green: 0.91, blue: 0.84, opacity: 1.00).edgesIgnoringSafeArea(.all)
            VStack (alignment: .center) {
                Spacer()
                Text("Congratulations 🥳")
                    .font(.title)
                    .fontWeight(.bold)
                Image("highScore")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxWidth: 350, maxHeight: 350, alignment: .center)
                Text("You've learned so much. You deserve a bowl of Bakso 😋")
                    .font(.system(size: 16))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                    .padding(.bottom, 15)
                NavigationLink(destination: QuizView()) {
                    Text("Take the quiz again")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(width:280, height: 50)
                        .background(Color("AccentColor"))
                        .cornerRadius(8)
                        .padding(.bottom,5)
                }
                NavigationLink(destination: HomeView()) {
                    Text("Back to Home")
                        .font(.system(size: 20))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(width:280, height: 50)
                        .background(Color("AccentColor"))
                        .cornerRadius(8)
                        .padding(.bottom,5)
                }
                Spacer()
                    .onAppear(){
                        SaveScore(quiz: "myQuiz1", score: self.score)
                    }
            }
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

struct QuizFinalView_Previews: PreviewProvider {
    static var previews: some View {
        QuizFinalView(score: 10).previewDevice(PreviewDevice(rawValue: "iPhone 13")).previewInterfaceOrientation(.portrait)
    }
}

