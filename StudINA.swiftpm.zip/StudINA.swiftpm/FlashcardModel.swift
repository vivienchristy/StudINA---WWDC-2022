//
//  File.swift
//  StudINA
//
//  Created by Vivien Christy Apriyanti on 21/04/22.
//

import Foundation

struct FlashcardModel  {
    var provinceText : String
    var img : String
    var houseText : String
    var descText : String
}

var myFlashcard : [FlashcardModel] = [
        FlashcardModel(
            provinceText: "Nanggroe Aceh Darussalam",
            img: "1",
            houseText: "Krong Bade",
            descText: " The Krong Bade house is one of the almost extinct Indonesian cultures. This house has a front staircase that is used for guests or living people to enter the house."
        ),
        FlashcardModel(
            provinceText: "North Sumatera",
            img: "2",
            houseText: "Bolon",
            descText: "Bolon houses are made with wood. The house floor is made with boards. The roof is made with rumbia leaves. Bolon houses have no individual rooms."
        ),
        FlashcardModel(
            provinceText: "West Sumatera",
            img: "3",
            houseText: "Gadang",
            descText: "The architecture, construction, internal and external decoration, and the functions of the house reflect the culture and values of the Minangkabau."
        ),
        FlashcardModel(
            provinceText: "Riau",
            img: "4",
            houseText: "Selaso Jatuh Kembar",
            descText: "This traditional house is beautified with various kinds of carvings with plant and animal shapes. Each carving has a different meaning and name."
        ),
        FlashcardModel(
            provinceText: "Riau Islands",
            img: "5",
            houseText: "Potong Limas",
            descText: "Limas in Indonesian is pyramid. The term  Limas itself takes from the shape of the roof of the house which is in the shape of a pyramid."
        ),
        FlashcardModel(
            provinceText: "Bengkulu",
            img: "6",
            houseText: "Bubungan Lima",
            descText: "This house is built high to prevent homeowners and their families from being attacked by wild animals and also from natural disasters such as floods."
        ),
        FlashcardModel(
            provinceText: "Jambi",
            img: "7",
            houseText: "Rumah Panggung",
            descText: "This house is also known as the Kajang Lako house. This house is divided into 8 rooms."
        ),
        FlashcardModel(
            provinceText: "Lampung",
            img: "8",
            houseText: "Nuwo Sesat",
            descText: "On the front side of this traditional house there are carved boat ornaments that become the characteristic."
        ),
        FlashcardModel(
            provinceText: "South Sumatera",
            img: "9",
            houseText: "Limas",
            descText: "This house is also known as Rumah Bari which means'old house'.  These houses are associated with the nobility and other people of high status."
        ),
        FlashcardModel(
            provinceText: "Bangka Belitung",
            img: "10",
            houseText: "Rakit Limas",
            descText: "Nowadays, these houses that’s built on the banks of the Musi river are the residences of people of Chinese descent."
        ),
        FlashcardModel(
            provinceText: "Banten",
            img: "11",
            houseText: "Baduy",
            descText: "The material that can be used to build this Baduy traditional house is bamboo. The Baduy traditional house is a symbol of the community."
        ),
        FlashcardModel(
            provinceText: "DKI Jakarta",
            img: "12",
            houseText: "Rumah Kebaya",
            descText: "Rumah Kebaya is a name of a Betawi traditional house. The name comes from the shape of the roof, which resembles a fold of the Kebaya form of dress."
        ),
        FlashcardModel(
            provinceText: "West Java",
            img: "13",
            houseText: "Kasepuhan",
            descText: "Rumah Kasepuhan has a house shape that widens to the side, so it looks like a stage. This form can almost be found in all parts of the Kasepuhan House."
        ),
        FlashcardModel(
            provinceText: "Central Java",
            img: "14",
            houseText: "Joglo",
            descText: "In the highly hierarchical Javanese culture, the type of the roof of a house reflects the social and economic status of the owners of the house; joglo houses is traditionally associated with Javanese aristocrats."
        ),
        FlashcardModel(
            provinceText: "DI Yogyakarta",
            img: "15",
            houseText: "Joglo",
            descText: "In the highly hierarchical Javanese culture, the type of the roof of a house reflects the social and economic status of the owners of the house; joglo houses is traditionally associated with Javanese aristocrats."
        ),
        FlashcardModel(
            provinceText: "East Java",
            img: "16",
            houseText: "Joglo",
            descText: "In the highly hierarchical Javanese culture, the type of the roof of a house reflects the social and economic status of the owners of the house; joglo houses is traditionally associated with Javanese aristocrats."
        ),
        FlashcardModel(
            provinceText: "West Kalimantan",
            img: "17",
            houseText: "Rumah Panjang",
            descText: "The  tradisional house is a hallmark of the Dayak people who live in the West Kalimantan area. This house is also the center of life for the Dayak people."
        ),
        FlashcardModel(
            provinceText: "East Kalimantan",
            img: "18",
            houseText: "Rumah Lamin",
            descText: "This house is the identity of the Dayak community in East Kalimantan.  Rumah Lamin can accommodate approximately 100 people."
        ),
        FlashcardModel(
            provinceText: "South Kalimantan",
            img: "19",
            houseText: "Bubungan Tinggi",
            descText: "Its name Bubungan Tinggi refers to the steep roof (45 degrees). In the old kingdom time, this house was the core building within a palace complex, where the King and his family resided."
        ),
        FlashcardModel(
            provinceText: "Central Kalimantan",
            img: "20",
            houseText: "Betang",
            descText: "The hallmark of the Betang house is its shape which extends more than 100 meters using a wooden structure. Each Betang House is inhabited by 100-150 people."
        ),
        FlashcardModel(
            provinceText: "North Kalimantan",
            img: "21",
            houseText: "Rumah Baloy",
            descText: "This traditional house is the result of the architectural art culture of the Tidung tribal community, North Kalimantan."
        ),
        FlashcardModel(
            provinceText: "Gorontalo",
            img: "22",
            houseText: "Dulohupa",
            descText: "Dulohupa has the form of a house on stilts with a body made of boards and a roof structure with the nuances of the Gorontalo area. Dulohupa has decorations in the form of wooden pillars."
        ),
        FlashcardModel(
            provinceText: "West Sulawesi",
            img: "23",
            houseText: "Rumah Boyang",
            descText: "This house is the residence of the Mandar Tribe, which is a native tribe from West Sulawesi."
        ),
        FlashcardModel(
            provinceText: "Central Sulawesi",
            img: "24",
            houseText: "Souraja",
            descText: "This Souraja is the remains of a building relic of the Palu (Central Sulawesi’s capital city) Kingdom at that time which was built by the King of Palu."
        ),
        FlashcardModel(
            provinceText: "North Sulawesi",
            img: "25",
            houseText: "Walewangko",
            descText: "This house is also used as a storage place for local residents' crops. The house is in the form of a house on stilts."
        ),
        FlashcardModel(
            provinceText: "Sourtheast Sulawesi",
            img: "26",
            houseText: "Buton",
            descText: "The Buton traditional house or Buton Palace is a building on a pillar, and is entirely made of wood. The building consists of four levels or four floors."
        ),
        FlashcardModel(
            provinceText: "South Sulawesi",
            img: "27",
            houseText: "Tongkonan",
            descText: "Tongkonan is the traditional house of the Toraja people, which is the residence, customary power, and development of the socio-cultural life of the Toraja people."
        ),
        FlashcardModel(
            provinceText: "Bali",
            img: "28",
            houseText: "Gapura Candi Bentar",
            descText: "This house’s distinctive architectural design with rich carvings and sculptures seems to reflect the life of the Balinese people and their beliefs."
        ),
        FlashcardModel(
            provinceText: "East Nusa Tenggara",
            img: "29",
            houseText: "Musalaki",
            descText: "This traditional house itself is a special residence for tribal chiefs from several tribes in the province of East Nusa Tenggara."
        ),FlashcardModel(
            provinceText: "West Nusa Tenggara",
            img: "30",
            houseText: "Dalam Loka",
            descText: "This house is a historical relic from the Sumbawa kingdom. Rumah Dalam Loka looks very majestic. It’s a  palace built with wood, with the traditional Sumbawa philosophy."
        ),
        FlashcardModel(
            provinceText: "Maluku",
            img: "31",
            houseText: "Baileo",
            descText: "The house is a representation of the Baileo Maluku culture and has an important function in the life of the community."
        ),
        FlashcardModel(
            provinceText: "North Maluku",
            img: "32",
            houseText: "Sasadu",
            descText: "Sasadu is the traditional house of the Sahu tribe in West Halmahera which is also the original and oldest ethnic group in the area."
        ),
        FlashcardModel(
            provinceText: "West Papua",
            img: "33",
            houseText: "Mod Aki Aksa",
            descText: "Is called the house of a thousand feet because it uses a lot of support poles under it, so if you look at it it has many legs like a millipede."
        ),
        FlashcardModel(
            provinceText: "Papua",
            img: "34",
            houseText: "Honai",
            descText: "This house has a characteristic that is in the form of a circular base with a wooden frame and a conical roof made of straw. "
        ),
]
